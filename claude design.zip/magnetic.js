/* Magnetic CTA engine. Attach to any .mag or .link-mag element.
   Optional data-mag="<px>" sets pull strength (default 10). */
(function(){
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const lerp = (a, b, t) => a + (b - a) * t;

  function bind(el){
    const inner = el.querySelector('.mag-inner');
    const strength = parseFloat(el.dataset.mag || '10');
    if (!inner) return;
    let rect = null, raf = null;
    let tx = 0, ty = 0, ix = 0, iy = 0;
    let targetX = 0, targetY = 0, targetIX = 0, targetIY = 0;
    let inside = false;
    const measure = () => rect = el.getBoundingClientRect();
    const loop = () => {
      tx = lerp(tx, targetX, 0.22); ty = lerp(ty, targetY, 0.22);
      ix = lerp(ix, targetIX, 0.22); iy = lerp(iy, targetIY, 0.22);
      el.style.transform = `translate(${tx.toFixed(2)}px, ${ty.toFixed(2)}px) scale(${inside ? 1.02 : 1})`;
      inner.style.transform = `translate(${ix.toFixed(2)}px, ${iy.toFixed(2)}px)`;
      if (Math.abs(tx-targetX)>0.1 || Math.abs(ty-targetY)>0.1 || Math.abs(ix-targetIX)>0.1 || Math.abs(iy-targetIY)>0.1){
        raf = requestAnimationFrame(loop);
      } else raf = null;
    };
    const kick = () => { if (!raf && !reduced) raf = requestAnimationFrame(loop); };
    const onMove = (e) => {
      if (!rect) measure();
      const nx = (e.clientX - (rect.left + rect.width/2)) / (rect.width/2);
      const ny = (e.clientY - (rect.top + rect.height/2)) / (rect.height/2);
      targetIX = Math.max(-1, Math.min(1, nx)) * strength;
      targetIY = Math.max(-1, Math.min(1, ny)) * strength;
      targetX = targetIX * 0.5; targetY = targetIY * 0.5;
      const fillEl = el.querySelector('.mag-fill');
      if (fillEl){
        const px = ((e.clientX - rect.left) / rect.width) * 100;
        const py = ((e.clientY - rect.top) / rect.height) * 100;
        fillEl.style.setProperty('--fx', px.toFixed(1) + '%');
        fillEl.style.setProperty('--fy', py.toFixed(1) + '%');
      }
      kick();
    };
    const onEnter = () => { measure(); inside = true; kick(); };
    const onLeave = () => {
      inside = false;
      targetX = targetY = targetIX = targetIY = 0;
      el.style.transition = 'transform 480ms cubic-bezier(.22,1,.36,1), border-color 280ms ease, color 280ms ease, background 280ms ease, box-shadow 280ms ease';
      inner.style.transition = 'transform 480ms cubic-bezier(.22,1,.36,1)';
      requestAnimationFrame(() => {
        el.style.transform = 'translate(0,0) scale(1)';
        inner.style.transform = 'translate(0,0)';
        tx = ty = ix = iy = 0;
      });
      setTimeout(() => { el.style.transition = ''; inner.style.transition = ''; }, 520);
    };
    el.addEventListener('pointerenter', onEnter);
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerleave', onLeave);
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, { passive: true });
    el.addEventListener('focus', () => {
      if (reduced) return;
      el.style.transition = 'transform 280ms cubic-bezier(.22,1,.36,1), border-color 280ms ease, color 280ms ease, background 280ms ease, box-shadow 280ms ease';
      inner.style.transition = 'transform 280ms cubic-bezier(.22,1,.36,1)';
      el.style.transform = 'translate(0,-2px) scale(1.01)';
    });
    el.addEventListener('blur', () => {
      el.style.transform = ''; inner.style.transform = '';
      setTimeout(() => { el.style.transition = ''; inner.style.transition = ''; }, 300);
    });
  }

  function bindAll(root){
    (root || document).querySelectorAll('.mag, .link-mag').forEach(bind);
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', () => bindAll());
  } else {
    bindAll();
  }

  window.magnetic = { bind, bindAll };
})();
