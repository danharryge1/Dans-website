# Motion System — Integration Guide

**Phase 8** ships the magnetic CTA engine + three signature moments into the live Next.js codebase. Everything in this doc refers to the React / TS wiring; the four standalone HTML deliverables (`Step 1`–`Step 4`) are the design specs those wirings implement.

---

## What shipped

| Primitive | Path | Used by |
|---|---|---|
| `useMagnetic` hook | `lib/motion/useMagnetic.ts` | `MagneticButton` (and anything else that wants pointer pull) |
| `MagneticButton` | `lib/motion/MagneticButton.tsx` | Contact submit (`solid`), any future CTA |
| `useInViewReveal` | `lib/motion/useInViewReveal.ts` | Optional non-GSAP reveal driver |
| Motion tokens + keyframes | `app/globals.css` (Phase 8 block) | All of the above + the three moments |

### Signature moments
1. **Ledger reveal** — Services cards stamp in on scroll. `ServicesClient` toggles `data-reveal="1"` once per card; `ledger-stamp` keyframe drives the settle. The existing gold sweep + arc draw are untouched.
2. **Tap to Sink** — Philosophy headlines settle as if struck into the page. `PhilosophyClient` toggles `data-reveal="1"` on each `[data-philosophy-block]`; `philosophy-sink` keyframe drives the `h3`.
3. **Sign the Page** — Contact submit underlines its label on hover / focus. `ContactForm` now renders `MagneticButton variant="solid"` wrapped in `[data-contact-submit]` so the existing reveal stagger + the new underline pair correctly.

---

## Using `MagneticButton`

```tsx
import { MagneticButton } from "@/lib/motion/MagneticButton";

// Anchor
<MagneticButton href="/work" variant="outline">See the work</MagneticButton>

// Submit
<MagneticButton type="submit" variant="solid" strength={14}>Send it</MagneticButton>

// Secondary / footer
<MagneticButton href="#contact" variant="ghost" arrow={false}>
  Email direct
</MagneticButton>
```

**Variants and when to use them**
- `solid` (gold bg, dark text) — the one primary conversion on a view. Pull strength 14.
- `outline` (transparent, cream border, gold radial fill) — every other CTA. Pull strength 10.
- `ghost` (muted cream, smaller) — secondary nav, footer, inline prompts. Pull strength 8.

**Accessibility**
- Renders as `<a>` when `href` is set, otherwise `<button>` with correct `type`.
- Focus-visible ring uses `--gold-accent` tokens.
- `prefers-reduced-motion` and `pointer: coarse` disable the magnetic pull entirely; hover states degrade to a normal color transition.

---

## Adding new signature moments

Pattern: write a keyframe in `globals.css` that triggers on `[data-your-thing][data-reveal="1"]`, then from the section's client component call `el.dataset.reveal = "1"` at the right scroll trigger. Works inside existing GSAP contexts (see `ServicesClient` for the scrubbed variant and `PhilosophyClient` for the one-shot variant).

For new sections that don't need scrub, import `useInViewReveal` — it stamps `--reveal: 1` + `data-reveal="1"` on enter with no GSAP dependency.

---

## Motion tokens (globals.css Phase 8 block)

```css
--ease-snap: cubic-bezier(.22, 1, .36, 1);  /* signatures, arrow glyphs */
--ease-soft: cubic-bezier(.4, 0, .2, 1);    /* color / border / opacity */
--dur-quick: 220ms;
--dur-base: 320ms;
--dur-slow: 480ms;
--reveal: 1;                                /* shared reveal channel */
```

Retune from here; every CTA and signature moment reads these.

---

## Files changed

- `app/globals.css` — appended the Phase 8 block (motion tokens, `.magb` styles, the three moment keyframes, reduced-motion overrides).
- `components/sections/Services/ServicesClient.tsx` — added `data-reveal` stamp on both desktop scrub and mobile one-shot paths.
- `components/sections/Philosophy/PhilosophyClient.tsx` — added `data-reveal` stamp inside the existing per-block `ScrollTrigger.onEnter`.
- `components/sections/Contact/ContactForm.tsx` — replaced the hand-rolled submit button with `MagneticButton variant="solid"`, kept the `data-contact-submit` wrapper so the Contact reveal stagger still applies.

## Files added

- `lib/motion/useMagnetic.ts`
- `lib/motion/MagneticButton.tsx`
- `lib/motion/useInViewReveal.ts`
- `INTEGRATION.md` (this file)

---

## Testing notes

- The existing test suites for `ContactForm`, `ServicesClient`, and `PhilosophyClient` still pass — the changes add behaviour rather than modify the existing DOM contract. The submit button's `data-contact-submit` attribute is preserved (just moved onto the wrapper div) so `ContactClient`'s reveal stagger still finds it.
- Add unit coverage for `MagneticButton` variant-to-DOM mapping (anchor vs button render) and for `useMagnetic` gating under `pointer: coarse` / reduced motion when you next touch this layer.
- Lighthouse / a11y: magnetic pull is decorative and opt-out via user preference; contrast was not changed.
