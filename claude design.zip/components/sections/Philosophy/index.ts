export { Philosophy } from "./Philosophy";
